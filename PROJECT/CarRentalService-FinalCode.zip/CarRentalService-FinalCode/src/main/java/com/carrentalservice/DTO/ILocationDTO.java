package com.carrentalservice.DTO;

public interface ILocationDTO {

	public String getDestination();
	public String getSource();
	
	
	
}
