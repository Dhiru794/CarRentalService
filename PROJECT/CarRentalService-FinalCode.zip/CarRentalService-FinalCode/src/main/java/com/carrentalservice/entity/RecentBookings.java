package com.carrentalservice.entity;

import javax.persistence.Entity;


public class RecentBookings {
//
//	private String booking_date;
//	private String customer_firstname;
//	private String source;
//	private String destination;
//	private int total_ride_price;
//	
//	public RecentBookings() {
//		
//	}
//	
//	public RecentBookings(String booking_date, String customer_firstname, String source, String destination,
//			int total_ride_price) {
//		super();
//		this.booking_date = booking_date;
//		this.customer_firstname = customer_firstname;
//		this.source = source;
//		this.destination = destination;
//		this.total_ride_price = total_ride_price;
//	}
//	
//	public String getBooking_date() {
//		return booking_date;
//	}
//	public void setBooking_date(String booking_date) {
//		this.booking_date = booking_date;
//	}
//	public String getCustomer_firstname() {
//		return customer_firstname;
//	}
//	public void setCustomer_firstname(String customer_firstname) {
//		this.customer_firstname = customer_firstname;
//	}
//	public String getSource() {
//		return source;
//	}
//	public void setSource(String source) {
//		this.source = source;
//	}
//	public String getDestination() {
//		return destination;
//	}
//	public void setDestination(String destination) {
//		this.destination = destination;
//	}
//	public int getTotal_ride_price() {
//		return total_ride_price;
//	}
//	public void setTotal_ride_price(int total_ride_price) {
//		this.total_ride_price = total_ride_price;
//	}
//
//	@Override
//	public String toString() {
//		return "RecentBookings [booking_date=" + booking_date + ", customer_firstname=" + customer_firstname
//				+ ", source=" + source + ", destination=" + destination + ", total_ride_price=" + total_ride_price
//				+ "]";
//	}
}
