package com.carrentalservice.DTO;

public interface IFeedbackDTO {

	public String getFeedback();
	public String getFirstName();
	public String getLastName();
	public int getRating();
	
}