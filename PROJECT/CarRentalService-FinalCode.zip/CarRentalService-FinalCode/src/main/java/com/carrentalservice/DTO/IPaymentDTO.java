package com.carrentalservice.DTO;

public interface IPaymentDTO {
	public String getCustomerName();
	public String getVehicleName();
	public int getAmount();
	public String getJourneyDateandTime();
}
