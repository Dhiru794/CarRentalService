package com.example.carrentalservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarRentalServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
